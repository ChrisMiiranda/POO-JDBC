public class Tarefa {
	
	private int id;
	private String item;
	private int situacao;//1) Feito; 2) N�o Feito
	
	public Tarefa(String item, int situacao) {
		this.item = item;
		this.situacao = situacao;
	}
	
	public Tarefa(int id, String item, int situacao) {
		this.id = id;
		this.item = item;
		this.situacao = situacao;
	}
	
	public int getId() {
		return id;
	}
	public String getItem() {
		return item;
	}
	public void setItem(String item) {
		this.item = item;
	}
	public int getSituacao() {
		return situacao;
	}
	public void setSituacao(int situacao) {
		this.situacao = situacao;
	}

	public String toString() {
		String retorno = "("+getId()+")"+getItem()+": ";
		String status=null;
		if(getSituacao()==1) {
			status = "Feito";
		}else {
			status = "N�o Feito";
		}
		return retorno +=status;
	}
	
}

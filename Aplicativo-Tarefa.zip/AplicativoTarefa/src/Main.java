import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		TarefaDAO dao = new TarefaDAO();
		
		//inserimos a tarefa estaticamente
		Tarefa tarefa1 = new Tarefa("ir no resturante", 2);
		dao.insert(tarefa1);
		Tarefa tarefa2 = new Tarefa("ir no medico", 2);
		dao.insert(tarefa2);
		Tarefa tarefa3 = new Tarefa("fazer almoco", 2);
		dao.insert(tarefa3);
		Tarefa tarefa4 = new Tarefa("lavar dog", 2);
		dao.insert(tarefa4);
		
		int opcao=0;
		while(opcao!=9) {
			System.out.println("Digite uma op��o desejada:");
			System.out.println("1) Checar Tarefa");
			System.out.println("2) Alterar Tarefa");
			System.out.println("3) Deletar Tarefa");
			System.out.println("4) Listar Tarefas");
			System.out.println("9) SAIR");
			opcao = input.nextInt();
			if(opcao==1) {
				for(Tarefa tarefa : dao.getAll()) {
					System.out.println(tarefa);
				}
				int sair=0;
				while(sair!=9) {
					System.out.println("Digite o id da tarefa para mudar sua situa��o");
					int idTarefa = input.nextInt();
					System.out.println("Digite a situa��o 1) Feito; 2) N�o Feito");
					int situacaoTarefa = input.nextInt();
					dao.updateSituacao(idTarefa, situacaoTarefa);
					System.out.println("Voltar para o menu � 9; 1 para continuar");
					sair = input.nextInt();
				}
			}else if(opcao==2) {
				for(Tarefa tarefa : dao.getAll()) {
					System.out.println(tarefa);
				}
				int sair=0;
				while(sair!=9) {
					System.out.println("Digite o id da tarefa que deseja atualizar");
					int idTarefa = input.nextInt();
					input.nextLine();
					System.out.println("Digite o novo nome do item: ");
					String itemNome = input.nextLine();
					System.out.println("Digite a situa��o 1) Feito; 2) N�o Feito");
					int situacaoTarefa = input.nextInt();
					Tarefa tarefa = new Tarefa(idTarefa, itemNome, situacaoTarefa);
					dao.updateTudo(tarefa);
					System.out.println("Voltar para o menu � 9; 1 para continuar");
					sair = input.nextInt();
				}
			}else if(opcao==3) {
				for(Tarefa tarefa : dao.getAll()) {
					System.out.println(tarefa);
				}
				System.out.println("Digite o id da tarefa que deseja deletar");
				int idTarefa = input.nextInt();
				dao.delete(idTarefa);
			}else if(opcao==4){
				for(Tarefa tarefa : dao.getAll()) {
					System.out.println(tarefa);
				}
			}else if(opcao==9) {
				System.out.println("Programa Encerado");
				break;//fecha while
			}
		}
	}
}


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TarefaDAO extends BasicoDAO{
	
	public void insert(Tarefa tarefas) {

		String sql = "insert into tarefas(item, situacao) values(?,?)";
		try {
			
			// try with-resources
			
			try (Connection conn = getConnection();
				 PreparedStatement statement = conn.prepareStatement(sql)){
				
				statement.setString(1, tarefas.getItem());
				statement.setInt(2, tarefas.getSituacao());
				statement.execute();
			}
		}catch (Exception e){
			e.printStackTrace();
		}
		
	}
	
	public void delete(int idTarefa) {
		
		String sql = "delete from tarefas where id = ?";
		
		try(Connection conn = getConnection();
			PreparedStatement statement = conn.prepareStatement(sql)) {
			statement.setInt(1, idTarefa);
			statement.execute();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	public void updateSituacao(int idTarefa, int situacaoTarefa) {
		String sql = "update tarefas set situacao = ? where id = ?";
		try (Connection conn = getConnection();
			 PreparedStatement statement = conn.prepareStatement(sql)){
			statement.setInt(1, situacaoTarefa);
			statement.setInt(2, idTarefa);
			statement.execute();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

	public void updateTudo(Tarefa tarefas) {
		String sql = "update tarefas set item = ?, situacao = ? where id = ?";
		
		try (Connection conn = getConnection();
			 PreparedStatement statement = conn.prepareStatement(sql)){
			statement.setString(1, tarefas.getItem());
			statement.setInt(2, tarefas.getSituacao());
			statement.setInt(3, tarefas.getId());
			statement.execute();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

	public Tarefa getById(int id) {
		Tarefa tarefas = null;
		String sql = "select id, item, situacao from tarefas where id = ?";
		
		try(Connection conn = getConnection();
			PreparedStatement statement = conn.prepareStatement(sql)) {
			statement.setInt(1, id);
			ResultSet resultSet = statement.executeQuery();
			if(resultSet.next()) {
				tarefas = new Tarefa(resultSet.getInt(1), resultSet.getString(2), resultSet.getInt(3));
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return tarefas;
	}

	public List<Tarefa> getAll(){
		List<Tarefa> list = new ArrayList<>();
		String sql = " select id, item, situacao from tarefas order by id";
		
		try(Connection conn = getConnection();
			PreparedStatement statement = conn.prepareStatement(sql)) {
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				Tarefa tarefas = new Tarefa(resultSet.getInt(1), resultSet.getString(2), resultSet.getInt(3));
				list.add(tarefas);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
}
